# AWS for Database Administrators — downloadable lab code
# Chapter 3 — Hands-on Lab: Service-selection inventory and comparison
# Block: List available PostgreSQL and MySQL versions and instance classes
# Execution environment: lenovaonprem2; AWS read permissions.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws rds describe-db-engine-versions --engine postgres --region us-east-2 --query 'DBEngineVersions[0:5].[EngineVersion,Status]' --output table
aws rds describe-db-engine-versions --engine mysql --region us-east-2 --query 'DBEngineVersions[0:5].[EngineVersion,Status]' --output table
aws rds describe-orderable-db-instance-options --engine postgres --engine-version 17 --region us-east-2 --query 'OrderableDBInstanceOptions[0:5].[DBInstanceClass,StorageType]' --output table
