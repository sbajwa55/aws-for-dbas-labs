# AWS for Database Administrators — downloadable lab code
# L.16 Oracle Instant Client and database connectivity
# Block: Check the Oracle client and the network path to the database
# Book: Install an Instant Client version compatible with the target databases
#       and application drivers. Keep Oracle client libraries and network
#       configuration discoverable through documented environment settings.
#       Prefer service names and TLS where supported rather than hard-coded IP
#       addresses.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

sqlplus -v
tnsping <service_alias>
getent hosts hponprem1.bcs.com
nc -vz 192.168.55.2 1521
