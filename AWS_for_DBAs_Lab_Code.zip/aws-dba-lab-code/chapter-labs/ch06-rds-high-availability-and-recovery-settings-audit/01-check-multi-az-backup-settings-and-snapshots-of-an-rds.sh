# AWS for Database Administrators — downloadable lab code
# Chapter 6 — Hands-on Lab: RDS high-availability and recovery settings audit
# Block: Check Multi-AZ, backup settings and snapshots of an RDS instance
# Execution environment: lenovaonprem2; existing RDS instance.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws rds describe-db-instances --db-instance-identifier "$DB_ID" --region us-east-2 --query 'DBInstances[0].{MultiAZ:MultiAZ,BackupDays:BackupRetentionPeriod,PreferredBackup:PreferredBackupWindow,Status:DBInstanceStatus}'
aws rds describe-db-snapshots --db-instance-identifier "$DB_ID" --region us-east-2 --query 'DBSnapshots[].{ID:DBSnapshotIdentifier,Status:Status,Created:SnapshotCreateTime}' --output table
