-- AWS for Database Administrators — downloadable lab code
-- L.19 Sample datasets, validation, and evidence
-- Block: Count rows in the HEALTH sample schema
-- Book: Use non-sensitive datasets with documented schema and row counts. The
--       extended Oracle lab includes a HEALTH schema with tables such as
--       CITIES, CITY_WEATHER, HEXERCISE, HUSERS, and HVITALS. The weather
--       dataset can support aggregation and migration tests; exercise data
--       must not contain real patient information or credentials.
--
-- Paste these statements at the database prompt (SQL>, mysql> or psql)
-- named in the book, then compare the results with the expected values.
-- ----------------------------------------------------------------------

SELECT COUNT(*) FROM health.cities;
SELECT COUNT(*) FROM health.city_weather;
SELECT MIN(hdate), MAX(hdate) FROM health.hvitals;
