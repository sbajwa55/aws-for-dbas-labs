# AWS for Database Administrators — downloadable lab code
# Chapter 1 — Hands-on Lab: DBA responsibility and environment inventory
# Block: Check the host: name, kernel, OS, memory, disks, services and addresses
# Execution environment: hponprem1, hponprem2, lenovaonprem1, lenovaonprem2.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

hostnamectl
uname -r
cat /etc/os-release
free -h
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT
systemctl --failed
ip -br address
