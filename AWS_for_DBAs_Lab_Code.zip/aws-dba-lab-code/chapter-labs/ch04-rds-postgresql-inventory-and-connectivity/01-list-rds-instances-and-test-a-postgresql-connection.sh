# AWS for Database Administrators — downloadable lab code
# Chapter 4 — Hands-on Lab: RDS PostgreSQL inventory and connectivity
# Block: List RDS instances and test a PostgreSQL connection
# Execution environment: lenovaonprem2; existing authorized RDS PostgreSQL
# instance and network access.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws rds describe-db-instances --region us-east-2 --query 'DBInstances[].{ID:DBInstanceIdentifier,Engine:Engine,Status:DBInstanceStatus,Endpoint:Endpoint.Address}' --output table
# Replace DB_HOST and DB_USER with your authorized instance details.
PGPASSWORD="$DB_PASSWORD" psql "host=$DB_HOST port=5432 user=$DB_USER dbname=postgres sslmode=require" -c 'SELECT version(), current_database(), current_user;'
PGPASSWORD="$DB_PASSWORD" psql "host=$DB_HOST port=5432 user=$DB_USER dbname=postgres sslmode=require" -c 'SELECT now();'
