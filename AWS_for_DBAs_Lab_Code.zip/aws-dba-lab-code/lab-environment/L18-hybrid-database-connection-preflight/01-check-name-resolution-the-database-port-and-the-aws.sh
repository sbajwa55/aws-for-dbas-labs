# AWS for Database Administrators — downloadable lab code
# L.18 Hybrid database connection preflight
# Block: Check name resolution, the database port and the AWS identity
# Book: For every source-to-target test, record hostname, IP or DNS endpoint,
#       port, database service, user role, authentication method, and
#       encryption requirement. Validate name resolution, routing, port
#       access, TLS trust, login, and a harmless SELECT in that order. If the
#       source is on premises and the target is private in AWS, plan VPN,
#       Direct Connect, or another approved private path before migration.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

getent hosts <database_hostname>
nc -vz <database_hostname> <database_port>
aws sts get-caller-identity
