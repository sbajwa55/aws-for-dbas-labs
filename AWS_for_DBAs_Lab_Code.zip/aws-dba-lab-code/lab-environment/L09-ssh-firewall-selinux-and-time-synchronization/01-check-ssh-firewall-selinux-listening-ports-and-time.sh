# AWS for Database Administrators — downloadable lab code
# L.9 SSH, firewall, SELinux, and time synchronization
# Block: Check SSH, firewall, SELinux, listening ports and time sync
# Book: Use SSH keys, restrict inbound ports to approved hosts, and retain
#       SELinux enforcing mode unless a documented product requirement demands
#       an exception. A listening port does not imply network reachability;
#       verify both the host firewall and upstream controls. Keep chrony or an
#       equivalent time service healthy for logs, authentication, and
#       replication.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

sudo systemctl status sshd firewalld chronyd
getenforce
sudo firewall-cmd --list-all
ss -lntp
chronyc tracking
