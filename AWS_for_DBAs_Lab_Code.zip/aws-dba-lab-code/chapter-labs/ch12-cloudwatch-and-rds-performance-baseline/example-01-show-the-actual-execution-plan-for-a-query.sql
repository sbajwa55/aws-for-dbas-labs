-- AWS for Database Administrators — downloadable lab code
-- Chapter 12: Monitoring and Performance Tuning
-- In-chapter example from section: Read Execution Plans with Row Counts
-- Block: Show the actual execution plan for a query
-- Book: For a synthetic lab table, a SQL client example is:
--
-- Paste these statements at the database prompt (SQL>, mysql> or psql)
-- named in the book, then compare the results with the expected values.
-- ----------------------------------------------------------------------

EXPLAIN (ANALYZE, BUFFERS)
SELECT order_id, order_total
FROM lab_orders
WHERE customer_id = 42;
