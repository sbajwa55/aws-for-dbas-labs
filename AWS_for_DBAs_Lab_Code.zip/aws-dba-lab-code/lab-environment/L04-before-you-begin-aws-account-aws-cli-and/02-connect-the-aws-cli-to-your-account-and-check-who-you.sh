# AWS for Database Administrators — downloadable lab code
# L.4 Before You Begin: AWS Account, AWS CLI, and Software Downloads
# Block: Connect the AWS CLI to your account and check who you are
# Book: Next, connect the CLI to your account. If you use IAM Identity Center,
#       run aws configure sso; otherwise use aws configure with an access key
#       for a lab user. Configuration guide:
#       https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-
#       configure.html
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws configure sso
# or, with an access key for a lab user:
# aws configure
aws sts get-caller-identity
aws configure get region
