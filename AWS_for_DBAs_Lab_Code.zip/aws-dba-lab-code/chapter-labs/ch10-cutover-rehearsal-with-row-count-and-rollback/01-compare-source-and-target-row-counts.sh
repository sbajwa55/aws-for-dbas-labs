# AWS for Database Administrators — downloadable lab code
# Chapter 10 — Hands-on Lab: Cutover rehearsal with row-count and rollback checklist
# Block: Compare source and target row counts
# Execution environment: lenovaonprem1; two authorized PostgreSQL test
# databases.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

psql -h localhost -U postgres -d "$SOURCE_DB" -Atc "SELECT COUNT(*) FROM public.lab_orders;" > /tmp/source_count.txt
psql -h localhost -U postgres -d "$TARGET_DB" -Atc "SELECT COUNT(*) FROM public.lab_orders;" > /tmp/target_count.txt
diff -u /tmp/source_count.txt /tmp/target_count.txt || echo 'Counts differ: investigate before cutover'
# Also compare schema, sequences, constraints, indexes and application behavior.
