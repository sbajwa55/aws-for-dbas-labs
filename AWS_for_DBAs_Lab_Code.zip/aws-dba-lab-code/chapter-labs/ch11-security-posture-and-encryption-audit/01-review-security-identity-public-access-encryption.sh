# AWS for Database Administrators — downloadable lab code
# Chapter 11 — Hands-on Lab: Security posture and encryption audit
# Block: Review security: identity, public access, encryption, security groups and CloudTrail
# Execution environment: lenovaonprem2; AWS read permissions.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws sts get-caller-identity
aws rds describe-db-instances --region us-east-2 --query 'DBInstances[].{ID:DBInstanceIdentifier,Public:PubliclyAccessible,Encrypted:StorageEncrypted,KMS:KmsKeyId}' --output table
aws ec2 describe-security-groups --region us-east-2 --query 'SecurityGroups[].{Name:GroupName,ID:GroupId}' --output table
aws cloudtrail describe-trails --region us-east-2 --query 'trailList[].{Name:Name,MultiRegion:IsMultiRegionTrail}' --output table
