# AWS for Database Administrators — downloadable lab code
# L.5 Oracle Linux installation and release checks
# Block: Check the operating system, kernel, repositories and clock
# Book: Install Oracle Linux 8, 9, or 10 from an official installation image.
#       Select a minimal server profile, create a non-root administrator,
#       configure time synchronization, and update supported packages. Keep
#       each host on a version supported by its database or middleware
#       software. Do not upgrade a database server across major OS versions
#       without a compatibility review.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

cat /etc/os-release
uname -r
sudo dnf repolist
sudo dnf update --refresh
timedatectl status
