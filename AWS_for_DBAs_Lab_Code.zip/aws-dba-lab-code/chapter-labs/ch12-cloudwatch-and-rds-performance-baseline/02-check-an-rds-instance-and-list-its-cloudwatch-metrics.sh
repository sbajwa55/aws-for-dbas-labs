# AWS for Database Administrators — downloadable lab code
# Chapter 12 — Hands-on Lab: CloudWatch and RDS performance baseline
# Block: Check an RDS instance and list its CloudWatch metrics
# Execution environment: lenovaonprem2; existing RDS DB and CloudWatch
# permissions.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws rds describe-db-instances --db-instance-identifier "$DB_ID" --region us-east-2 --query 'DBInstances[0].[DBInstanceIdentifier,DBInstanceClass,Engine,DBInstanceStatus]'
aws cloudwatch list-metrics --namespace AWS/RDS --metric-name CPUUtilization --dimensions Name=DBInstanceIdentifier,Value="$DB_ID" --region us-east-2
aws cloudwatch list-metrics --namespace AWS/RDS --metric-name FreeStorageSpace --dimensions Name=DBInstanceIdentifier,Value="$DB_ID" --region us-east-2
