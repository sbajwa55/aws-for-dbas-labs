# AWS for Database Administrators — downloadable lab code
# L.12 Terraform installation and state handling
# Block: Check Terraform and validate a configuration
# Book: Install Terraform from an official distribution source. Pin the
#       provider version and review the execution plan before applying.
#       Protect state files because they can contain sensitive resource
#       details; use a controlled remote backend for shared projects.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

terraform version
terraform fmt -check
terraform init
terraform validate
terraform plan
