# AWS for Database Administrators — downloadable lab code
# L.7 Linux accounts, privileges, and filesystem layout
# Block: Check the oracle account, sudo rights, directory ownership and free space
# Book: Create named administrator accounts with sudo only where needed. Use
#       dedicated service accounts for Oracle, GoldenGate, and application
#       processes. Avoid sharing passwords or giving every service a root
#       shell. Document ownership of database homes, data directories, logs,
#       scripts, and backup paths.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

id oracle
getent passwd oracle
sudo -l
ls -ld /opt /u01 /var/log
df -hT
