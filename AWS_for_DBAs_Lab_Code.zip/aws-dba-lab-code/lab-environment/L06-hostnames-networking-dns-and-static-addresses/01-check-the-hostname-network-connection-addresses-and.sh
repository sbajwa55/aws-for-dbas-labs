# AWS for Database Administrators — downloadable lab code
# L.6 Hostnames, networking, DNS, and static addresses
# Block: Check the hostname, network connection, addresses and name resolution
# Book: Assign unique hostnames and reserve addresses at the DHCP server or
#       configure a managed static profile. Avoid changing a remote host’s
#       active network profile without console access. Verify the correct
#       connection name and gateway before applying changes. The examples
#       assume a 192.168.55.0/24 private LAN; never copy this range into a
#       production VPC without checking for overlap.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

hostnamectl status
nmcli connection show --active
ip -br address
ip route
getent hosts hponprem1.bcs.com
ping -c 2 192.168.55.2
