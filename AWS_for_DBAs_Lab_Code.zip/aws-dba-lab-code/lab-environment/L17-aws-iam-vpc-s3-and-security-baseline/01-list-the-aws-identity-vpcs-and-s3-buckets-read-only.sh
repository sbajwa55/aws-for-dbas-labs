# AWS for Database Administrators — downloadable lab code
# L.17 AWS IAM, VPC, S3, and security baseline
# Block: List the AWS identity, VPCs and S3 buckets (read-only)
# Book: Create a lab identity with least-privilege permissions and require MFA
#       where applicable. Design private database subnets in at least two
#       Availability Zones when the selected service requires them. Use
#       security-group rules that permit only intended clients. Create S3
#       buckets with public access blocked, encryption enabled, and lifecycle
#       policies appropriate to the exercise.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws sts get-caller-identity
aws ec2 describe-vpcs --output table
aws s3api list-buckets --query "Buckets[].Name" --output table
