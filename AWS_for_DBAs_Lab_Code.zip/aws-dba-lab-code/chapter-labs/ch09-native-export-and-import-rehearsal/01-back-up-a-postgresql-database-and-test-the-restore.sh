# AWS for Database Administrators — downloadable lab code
# Chapter 9 — Hands-on Lab: Native export and import rehearsal
# Block: Back up a PostgreSQL database and test the restore
# Execution environment: lenovaonprem1; local PostgreSQL test database.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

# Use a dedicated test database, not production.
pg_dump -h localhost -U postgres -Fc -d "$SOURCE_DB" -f /tmp/aws_book_lab.dump
pg_restore --list /tmp/aws_book_lab.dump | head -25
createdb -h localhost -U postgres aws_book_restore_test
pg_restore -h localhost -U postgres -d aws_book_restore_test /tmp/aws_book_lab.dump
psql -h localhost -U postgres -d aws_book_restore_test -c '\dt'
