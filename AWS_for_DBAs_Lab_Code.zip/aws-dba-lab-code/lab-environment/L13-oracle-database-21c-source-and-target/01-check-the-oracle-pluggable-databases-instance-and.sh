# AWS for Database Administrators — downloadable lab code
# L.13 Oracle Database 21c: source and target
# Block: Check the Oracle pluggable databases, instance and listener
# Book: The extended track uses BAJCDB1 on hponprem1 and BAJCDB2 on hponprem2,
#       each with BAJPDB1 and BAJPDB2 pluggable databases. Install Oracle only
#       with appropriate entitlement and on a certified platform. Configure
#       listener and service registration, then verify CDB and PDB state
#       before any replication or migration test.
#
# This block switches into a database client (sqlplus, psql, mysql).
# Paste the client command first, then paste the SQL at its prompt.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

sqlplus / as sysdba
SELECT name, open_mode FROM v$pdbs;
SELECT instance_name, status FROM v$instance;
-- At the OS shell:
lsnrctl status
