# AWS for Database Administrators — downloadable lab code
# Chapter 15: Infrastructure as Code and Automation
# In-chapter example from section: Plan Before Applying
# Block: Run the reviewed Terraform workflow and save the plan
# Book: For an existing, reviewed Terraform lab directory, the shell workflow
#       is:
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws sts get-caller-identity
terraform init
terraform fmt -check
terraform validate
terraform plan -out=reviewed.tfplan
