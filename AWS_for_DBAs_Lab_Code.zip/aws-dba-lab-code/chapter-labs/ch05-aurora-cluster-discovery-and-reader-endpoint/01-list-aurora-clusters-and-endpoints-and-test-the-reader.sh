# AWS for Database Administrators — downloadable lab code
# Chapter 5 — Hands-on Lab: Aurora cluster discovery and reader endpoint checks
# Block: List Aurora clusters and endpoints, and test the reader endpoint
# Execution environment: lenovaonprem2; existing Aurora cluster (if
# available).
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws rds describe-db-clusters --region us-east-2 --query 'DBClusters[].{ID:DBClusterIdentifier,Engine:Engine,Writer:Endpoint,Reader:ReaderEndpoint,Status:Status}' --output table
aws rds describe-db-cluster-endpoints --db-cluster-identifier "$CLUSTER_ID" --region us-east-2 --output table
# For Aurora PostgreSQL, test the reader endpoint using psql:
psql "host=$AURORA_READER port=5432 dbname=postgres user=$DB_USER sslmode=require" -c 'SELECT pg_is_in_recovery();'
