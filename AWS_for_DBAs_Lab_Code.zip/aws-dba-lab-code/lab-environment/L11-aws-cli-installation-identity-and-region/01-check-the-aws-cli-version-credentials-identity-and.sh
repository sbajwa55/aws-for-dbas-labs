# AWS for Database Administrators — downloadable lab code
# L.11 AWS CLI installation, identity, and region
# Block: Check the AWS CLI version, credentials, identity and Regions
# Book: Install AWS CLI v2 using the official architecture-specific installer
#       and verify its signature or checksum as directed by AWS. Prefer IAM
#       Identity Center or temporary role credentials over long-lived keys.
#       Choose a default Region intentionally; examples in this book should
#       state their Region explicitly when it matters.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws --version
aws configure list
aws sts get-caller-identity
aws ec2 describe-regions --query "Regions[].RegionName" --output text
