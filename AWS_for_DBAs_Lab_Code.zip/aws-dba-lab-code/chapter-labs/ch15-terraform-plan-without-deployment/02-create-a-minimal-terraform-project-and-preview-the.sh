# AWS for Database Administrators — downloadable lab code
# Chapter 15 — Hands-on Lab: Terraform plan without deployment
# Block: Create a minimal Terraform project and preview the account ID output
# Execution environment: lenovaonprem2; isolated Terraform working directory.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

mkdir -p ~/aws-book/terraform-lab && cd ~/aws-book/terraform-lab
cat > main.tf <<'EOF'
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}
provider "aws" { region = "us-east-2" }
data "aws_caller_identity" "current" {}
output "account_id" { value = data.aws_caller_identity.current.account_id }
EOF
terraform init
terraform fmt -check
terraform validate
terraform plan -out=plan.tfplan
terraform show plan.tfplan
