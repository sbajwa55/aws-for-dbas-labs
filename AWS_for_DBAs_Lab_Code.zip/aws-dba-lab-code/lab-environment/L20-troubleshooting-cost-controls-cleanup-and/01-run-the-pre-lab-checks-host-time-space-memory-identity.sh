# AWS for Database Administrators — downloadable lab code
# L.20 Troubleshooting, cost controls, cleanup, and chapter preflight
# Block: Run the pre-lab checks: host, time, space, memory, identity and plan
# Book: Before any chapter exercise: (1) verify host and OS versions; (2)
#       verify identity, Region, and intended account; (3) check source and
#       target connectivity; (4) confirm backups and restore points; (5)
#       estimate resource charges; (6) document success criteria; and (7)
#       prepare cleanup. Keep command output and decisions in a lab journal.
#       Never run destructive examples against production data.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

hostname -f
date -Is
df -h
free -h
aws sts get-caller-identity
terraform plan
