# AWS for Database Administrators — downloadable lab code
# Chapter 13 — Hands-on Lab: Backup and maintenance inventory
# Block: Check backup retention, maintenance window and snapshots
# Execution environment: lenovaonprem2; existing RDS instance.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws rds describe-db-instances --db-instance-identifier "$DB_ID" --region us-east-2 --query 'DBInstances[0].{Retention:BackupRetentionPeriod,Maintenance:PreferredMaintenanceWindow,AutoMinor:AutoMinorVersionUpgrade,EngineVersion:EngineVersion}'
aws rds describe-db-snapshots --db-instance-identifier "$DB_ID" --region us-east-2 --query 'DBSnapshots[].{ID:DBSnapshotIdentifier,Type:SnapshotType,Status:Status}' --output table
