# AWS for Database Administrators — downloadable lab code
# Chapter 16 — Hands-on Lab: Polyglot database service discovery and career portfolio
# Block: Check local database tools and list DynamoDB, DocumentDB and Neptune resources
# Execution environment: lenovaonprem1 and lenovaonprem2; read-only AWS
# access.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

# lenovaonprem1
psql --version
mysql --version
systemctl is-active postgresql-17 || true
# lenovaonprem2
aws dynamodb list-tables --region us-east-2 --output table
aws docdb describe-db-clusters --region us-east-2 --query 'DBClusters[].{ID:DBClusterIdentifier,Status:Status}' --output table
aws neptune describe-db-clusters --region us-east-2 --query 'DBClusters[].{ID:DBClusterIdentifier,Status:Status}' --output table
