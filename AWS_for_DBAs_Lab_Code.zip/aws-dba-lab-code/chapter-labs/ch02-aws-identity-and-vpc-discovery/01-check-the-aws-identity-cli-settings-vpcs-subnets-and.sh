# AWS for Database Administrators — downloadable lab code
# Chapter 2 — Hands-on Lab: AWS identity and VPC discovery
# Block: Check the AWS identity, CLI settings, VPCs, subnets and security groups
# Execution environment: lenovaonprem2; AWS account with read-only IAM, EC2,
# and VPC permissions.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws sts get-caller-identity
aws configure list
aws ec2 describe-vpcs --region us-east-2 --query 'Vpcs[].{Vpc:VpcId,Cidr:CidrBlock,Default:IsDefault}' --output table
aws ec2 describe-subnets --region us-east-2 --query 'Subnets[].{Subnet:SubnetId,AZ:AvailabilityZone,Vpc:VpcId}' --output table
aws ec2 describe-security-groups --region us-east-2 --query 'SecurityGroups[].{Group:GroupId,Name:GroupName,Vpc:VpcId}' --output table
