# AWS for Database Administrators — downloadable lab code
# L.14 PostgreSQL 17 and MySQL 8
# Block: Check the PostgreSQL and MySQL versions, services and ports
# Book: The integration host can run PostgreSQL and MySQL side by side with
#       distinct ports, data directories, service accounts, and backup
#       policies. Install packages from supported vendor repositories for the
#       selected Oracle Linux release; verify exact minor versions before
#       migration tests.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

psql --version
mysql --version
sudo systemctl status postgresql
sudo systemctl status mysqld
ss -lnt | grep -E ":(5432|3306) "
