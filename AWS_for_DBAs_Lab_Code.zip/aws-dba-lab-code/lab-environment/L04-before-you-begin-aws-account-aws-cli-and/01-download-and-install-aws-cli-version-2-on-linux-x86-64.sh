# AWS for Database Administrators — downloadable lab code
# L.4 Before You Begin: AWS Account, AWS CLI, and Software Downloads
# Block: Download and install AWS CLI version 2 on Linux (x86_64)
# Book: Installation guide:
#       https://docs.aws.amazon.com/cli/latest/userguide/getting-started-
#       install.html
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

cd /tmp
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" \
  -o "awscliv2.zip"
unzip -q awscliv2.zip
sudo ./aws/install
aws --version
