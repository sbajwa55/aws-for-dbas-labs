# AWS for Database Administrators — downloadable lab code
# Chapter 7 — Hands-on Lab: Oracle source assessment and sizing
# Block: Inventory the Oracle database: PDBs, tablespaces and schemas
# Execution environment: hponprem1; Oracle SQL*Plus as authorized DBA.
#
# This block switches into a database client (sqlplus, psql, mysql).
# Paste the client command first, then paste the SQL at its prompt.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

sqlplus / as sysdba
-- Execute the following SQL in SQL*Plus:
SELECT name, open_mode FROM v$pdbs;
SELECT tablespace_name, ROUND(SUM(bytes)/1024/1024) mb FROM dba_data_files GROUP BY tablespace_name ORDER BY 1;
SELECT owner, COUNT(*) objects FROM dba_objects WHERE owner NOT IN ('SYS','SYSTEM') GROUP BY owner ORDER BY objects DESC FETCH FIRST 15 ROWS ONLY;
EXIT
