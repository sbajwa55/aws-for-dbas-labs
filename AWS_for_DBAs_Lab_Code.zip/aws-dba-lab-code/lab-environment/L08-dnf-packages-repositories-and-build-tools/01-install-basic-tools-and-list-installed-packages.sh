# AWS for Database Administrators — downloadable lab code
# L.8 DNF packages, repositories, and build tools
# Block: Install basic tools and list installed packages
# Book: Confirm repository access before installing packages. On supported
#       hosts, install basic diagnostics and developer utilities; package
#       availability varies by release and enabled repository. Use vendor-
#       supported repositories for database software rather than mixing
#       arbitrary third-party RPMs.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

sudo dnf install -y git curl wget unzip tar jq vim-enhanced bind-utils
sudo dnf install -y python3 python3-pip
rpm -qa | sort | head
