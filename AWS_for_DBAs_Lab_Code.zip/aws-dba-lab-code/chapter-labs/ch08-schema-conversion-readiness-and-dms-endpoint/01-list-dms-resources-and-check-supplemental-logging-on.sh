# AWS for Database Administrators — downloadable lab code
# Chapter 8 — Hands-on Lab: Schema-conversion readiness and DMS endpoint inventory
# Block: List DMS resources and check supplemental logging on the source
# Execution environment: lenovaonprem2; AWS DMS read permissions; Oracle
# source.
#
# This block switches into a database client (sqlplus, psql, mysql).
# Paste the client command first, then paste the SQL at its prompt.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws dms describe-replication-instances --region us-east-2 --query 'ReplicationInstances[].{ID:ReplicationInstanceIdentifier,Status:ReplicationInstanceStatus}' --output table
aws dms describe-endpoints --region us-east-2 --query 'Endpoints[].{ID:EndpointIdentifier,Engine:EngineName,Type:EndpointType}' --output table
aws dms describe-replication-tasks --region us-east-2 --query 'ReplicationTasks[].{ID:ReplicationTaskIdentifier,Status:Status,MigrationType:MigrationType}' --output table
# On Oracle source, confirm supplemental logging:
sqlplus / as sysdba
SELECT supplemental_log_data_min FROM v$database;
EXIT
