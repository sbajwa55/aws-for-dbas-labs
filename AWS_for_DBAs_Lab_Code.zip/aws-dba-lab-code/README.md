# AWS for Database Administrators: From On-Premises to Cloud
## Downloadable lab code

Copyright © 2026 Sandeep S. Bajwa. All rights reserved.
Bajwa Consulting · bajwaconsulting.com

This archive contains every command, SQL statement, configuration file and
GoldenGate parameter file printed in the book's hands-on labs, so you can
copy and paste instead of typing. Each file matches one code box in the book,
in the same order, and starts with a comment header that tells you which
chapter or lab, which step, and which host to run it on.

## How to use these files

1. **Follow the book, not the folder.** The book explains why each step
   matters, what output to expect and how to check it. Open the matching
   file when you reach a code box.
2. **Paste, don't run.** The files are not meant to be run as one script.
   Paste a few lines at a time and compare the result with the book's
   expected output before you continue.
3. **Run on the right host.** The header line `Run on:` names the host
   (for example `lenovaonprem2` or the EC2 instance). On the minimal track,
   use your one VM for every role.
4. **Replace placeholders.** Anything in angle brackets, such as
   `<LAB_PASSWORD>`, `<your bucket name>` or `<SCN>`, must be replaced with
   your own value. Shell variables such as `$IID`, `$BUCKET` and `$VPC_ID`
   are set by earlier steps; if you open a new terminal, set them again.
   Type passwords at prompts; never save them into these files.
5. **Database prompts.** Files ending in `.sql` are pasted at the prompt
   named in the book (`SQL>`, `mysql>` or `psql`). Some `.sh` files start a
   database client and then continue with SQL; their header says so. Paste
   the client command first, then paste the SQL at its prompt.
6. **Ready-made files.** Where the book asks you to save a file, it is
   provided under its own name so you can copy it directly:
   `export_shop.sql` (Lab 2), `customers.ctl` and `orders.ctl` (Labs 3 and 4),
   and `ESHOP.prm` / `RSHOP.prm` (Lab 5). The comment lines at the top are
   valid comments in SQL*Plus, SQL*Loader and GoldenGate parameter files.
7. **GoldenGate Admin Client.** Files ending in `.txt` in Lab 5 hold Admin
   Client commands. The book wraps long commands to fit the page; in these
   files each command is on one line, as the Admin Client requires.

## Cost and safety

Use a separate lab account with synthetic data. The practice labs create
chargeable AWS resources (EC2, EBS, RDS, Secrets Manager, S3). Finish each
lab's Cleanup files and run the final "Confirm that no chargeable lab
resources remain" check. Review every command before you run it: some
steps change or delete resources. AWS services, versions and prices change
over time, so check current AWS documentation as well.

This book is independently authored and is not affiliated with, sponsored
by, or endorsed by Amazon Web Services.

## What's inside

`INDEX.csv` lists every file with its book section, step and code box title.

### chapter-labs/

The short hands-on lab at the end of each chapter (Chapters 1–16), plus the in-chapter examples from Chapters 12 and 15 (files named `example-...`).

- `chapter-labs/ch01-dba-responsibility-and-environment-inventory/` — Chapter 1 — Hands-on Lab: DBA responsibility and environment inventory (1 file)
- `chapter-labs/ch02-aws-identity-and-vpc-discovery/` — Chapter 2 — Hands-on Lab: AWS identity and VPC discovery (1 file)
- `chapter-labs/ch03-service-selection-inventory-and-comparison/` — Chapter 3 — Hands-on Lab: Service-selection inventory and comparison (1 file)
- `chapter-labs/ch04-rds-postgresql-inventory-and-connectivity/` — Chapter 4 — Hands-on Lab: RDS PostgreSQL inventory and connectivity (1 file)
- `chapter-labs/ch05-aurora-cluster-discovery-and-reader-endpoint/` — Chapter 5 — Hands-on Lab: Aurora cluster discovery and reader endpoint checks (1 file)
- `chapter-labs/ch06-rds-high-availability-and-recovery-settings-audit/` — Chapter 6 — Hands-on Lab: RDS high-availability and recovery settings audit (1 file)
- `chapter-labs/ch07-oracle-source-assessment-and-sizing/` — Chapter 7 — Hands-on Lab: Oracle source assessment and sizing (1 file)
- `chapter-labs/ch08-schema-conversion-readiness-and-dms-endpoint/` — Chapter 8 — Hands-on Lab: Schema-conversion readiness and DMS endpoint inventory (1 file)
- `chapter-labs/ch09-native-export-and-import-rehearsal/` — Chapter 9 — Hands-on Lab: Native export and import rehearsal (1 file)
- `chapter-labs/ch10-cutover-rehearsal-with-row-count-and-rollback/` — Chapter 10 — Hands-on Lab: Cutover rehearsal with row-count and rollback checklist (1 file)
- `chapter-labs/ch11-security-posture-and-encryption-audit/` — Chapter 11 — Hands-on Lab: Security posture and encryption audit (1 file)
- `chapter-labs/ch12-cloudwatch-and-rds-performance-baseline/` — Chapter 12 — Hands-on Lab: CloudWatch and RDS performance baseline (2 files)
- `chapter-labs/ch13-backup-and-maintenance-inventory/` — Chapter 13 — Hands-on Lab: Backup and maintenance inventory (1 file)
- `chapter-labs/ch14-cost-visibility-and-tagging-review/` — Chapter 14 — Hands-on Lab: Cost visibility and tagging review (1 file)
- `chapter-labs/ch15-terraform-plan-without-deployment/` — Chapter 15 — Hands-on Lab: Terraform plan without deployment (2 files)
- `chapter-labs/ch16-polyglot-database-service-discovery-and-career/` — Chapter 16 — Hands-on Lab: Polyglot database service discovery and career portfolio (1 file)

### lab-environment/

Setup and check commands for the lab environment, sections L.4 to L.20 (L.1–L.3, L.15, L.21 and L.22 have no code boxes).

- `lab-environment/L04-before-you-begin-aws-account-aws-cli-and/` — L.4 Before You Begin: AWS Account, AWS CLI, and Software Downloads (2 files)
- `lab-environment/L05-oracle-linux-installation-and-release-checks/` — L.5 Oracle Linux installation and release checks (1 file)
- `lab-environment/L06-hostnames-networking-dns-and-static-addresses/` — L.6 Hostnames, networking, DNS, and static addresses (1 file)
- `lab-environment/L07-linux-accounts-privileges-and-filesystem/` — L.7 Linux accounts, privileges, and filesystem layout (1 file)
- `lab-environment/L08-dnf-packages-repositories-and-build-tools/` — L.8 DNF packages, repositories, and build tools (1 file)
- `lab-environment/L09-ssh-firewall-selinux-and-time-synchronization/` — L.9 SSH, firewall, SELinux, and time synchronization (1 file)
- `lab-environment/L10-java-python-git-and-shell-environment/` — L.10 Java, Python, Git, and shell environment (1 file)
- `lab-environment/L11-aws-cli-installation-identity-and-region/` — L.11 AWS CLI installation, identity, and region (1 file)
- `lab-environment/L12-terraform-installation-and-state-handling/` — L.12 Terraform installation and state handling (1 file)
- `lab-environment/L13-oracle-database-21c-source-and-target/` — L.13 Oracle Database 21c: source and target (1 file)
- `lab-environment/L14-postgresql-17-and-mysql-8/` — L.14 PostgreSQL 17 and MySQL 8 (1 file)
- `lab-environment/L16-oracle-instant-client-and-database/` — L.16 Oracle Instant Client and database connectivity (1 file)
- `lab-environment/L17-aws-iam-vpc-s3-and-security-baseline/` — L.17 AWS IAM, VPC, S3, and security baseline (1 file)
- `lab-environment/L18-hybrid-database-connection-preflight/` — L.18 Hybrid database connection preflight (1 file)
- `lab-environment/L19-sample-datasets-validation-and-evidence/` — L.19 Sample datasets, validation, and evidence (1 file)
- `lab-environment/L20-troubleshooting-cost-controls-cleanup-and/` — L.20 Troubleshooting, cost controls, cleanup, and chapter preflight (1 file)

### practice-labs/

The five end-to-end migration labs from L.21. Files are numbered in book order and include the step number, for example `05-step0.4-...`.

- `practice-labs/lab1-oracle-to-oracle-on-amazon-ec2/` — Lab 1 — Oracle to Oracle on Amazon EC2 (25 files)
- `practice-labs/lab2-oracle-to-mysql-on-amazon-rds/` — Lab 2 — Oracle to MySQL on Amazon RDS (27 files)
- `practice-labs/lab3-mysql-to-oracle-on-ec2-and-postgresql-on-rds/` — Lab 3 — MySQL to Oracle on EC2 and PostgreSQL on RDS (32 files)
- `practice-labs/lab4-postgresql-to-oracle-on-amazon-ec2/` — Lab 4 — PostgreSQL to Oracle on Amazon EC2 (28 files)
- `practice-labs/lab5-oracle-goldengate-to-aws/` — Lab 5 — Oracle GoldenGate to AWS (37 files)

## File types

| Extension | What it is | Where you paste it |
|---|---|---|
| `.sh` | Linux shell and AWS CLI commands | A terminal on the host named in the header |
| `.sql` | SQL statements | The database prompt named in the book |
| `.ctl` | SQL*Loader control file | Save it as `customers.ctl` / `orders.ctl` |
| `.prm` | GoldenGate parameter file | Admin Client `EDIT PARAMS` editor |
| `.txt` | GoldenGate Admin Client commands | The Admin Client prompt |
