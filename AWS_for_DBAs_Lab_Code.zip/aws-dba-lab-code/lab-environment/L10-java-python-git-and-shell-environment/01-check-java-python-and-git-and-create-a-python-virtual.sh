# AWS for Database Administrators — downloadable lab code
# L.10 Java, Python, Git, and shell environment
# Block: Check Java, Python and Git, and create a Python virtual environment
# Book: Install a supported Java runtime only for products that require it.
#       Keep Python tools in isolated virtual environments and avoid modifying
#       system Python. Record versions in the lab inventory to make
#       troubleshooting reproducible.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

java -version
python3 --version
git --version
python3 -m venv ~/venvs/aws-dba
source ~/venvs/aws-dba/bin/activate
python -m pip --version
