# AWS for Database Administrators — downloadable lab code
# Chapter 14 — Hands-on Lab: Cost visibility and tagging review
# Block: Show daily AWS cost and list RDS instance sizes
# Execution environment: lenovaonprem2; AWS Cost Explorer permission.
#
# Paste these commands into a terminal a few lines at a time and check each
# result against the book. Do not run this file as one script.
# ----------------------------------------------------------------------

aws ce get-cost-and-usage --time-period Start=2026-11-01,End=2026-11-16 --granularity DAILY --metrics UnblendedCost --group-by Type=DIMENSION,Key=SERVICE --query 'ResultsByTime[].{Day:TimePeriod.Start,Total:Total}' --output json
aws rds describe-db-instances --region us-east-2 --query 'DBInstances[].{ID:DBInstanceIdentifier,Class:DBInstanceClass,Storage:AllocatedStorage}' --output table
